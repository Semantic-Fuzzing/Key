Project Structure:
cinema-KeY/  
├── build/  
│   ├── classes/  
│   │   ├── Cinema.class  
│   │   ├── Main.class  
│   │   └── Movie.class  
│   └── cinema.jar  
├── KeYclasspath/
│   └── java/  
│       └── util/
│            └── Scanner.java  
├── src/  
│   ├── Cinema.java  
│   ├── Main.java  
│   └── Movie.java  
├── build.xml  
├── cinema-KeY.iml  
├── cinema.iml  
└── key-2.10.0-exe.jar  

Instructions for Verifying the Project with KeY:

Step 1: Preparation
1.1 - Ensure Java 8 or higher is installed.
1.2 - The key-2.10.0-exe.jar file (included in the project) is required to work with KeY.

Step 2: Launching KeY
2.1 - Open a terminal in the cinema-KeY folder.
2.2 - Execute the command: "java -jar key-2.10.0-exe.jar" (Alternatively, manually open key-2.10.0-exe.jar.)

Step 3: Loading the Project
3.1 - In the KeY interface, select:
3.2 - File → Load...
3.3 - Specify the file Scanner.java.
3.4 - KeY will verify the correctness of JML specifications (if any) and the program logic.

