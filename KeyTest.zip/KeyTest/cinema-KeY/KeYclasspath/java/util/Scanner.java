package java.util;

//import java.io.Closeable;
import java.io.InputStream;

public final class Scanner {
    public Scanner(InputStream in);


    //@ ghost boolean endOfStream;
    //@ ghost byte nextIntInStream;
    //@ ghost boolean inputMismatch;
    //@ ghost boolean closed;
    /*@
        public normal_behavior
        // requires !endOfStream && !inputMismatch;
        ensures \result == nextIntInStream;
        accessible \nothing;
        assignable nextIntInStream, inputMismatch, endOfStream;

     */
    public /*@ helper */ int nextInt();
}