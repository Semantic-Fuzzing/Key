import java.util.Scanner;
import java.lang.System;

public class Cinema {
	private Movie[] movies;

	public Cinema(Movie[] movies) {
		this.movies = movies;
	}

	//@ assuming <pricePlausible> or <tooYoung>;
	public void nextCustomer(Scanner input) {
		//System.out.print("Enter age: ");
		int age = input.nextInt();
		//@ <junior>   assume age < 16;
		//@ <regular>  assume 16 <= age && age <  65;
		//@ <senior>   assume 65 <= age;

		//System.out.print("Select movie (1/2): ");
		int movieNumber = input.nextInt();
		//@ <mv1> assume movieNumber == 1;
		//@ <mv2> assume movieNumber == 2;
		// implicit assumption added for KeY:
		//@ assume 0 <= movieNumber && movieNumber < movies.length;
		Movie movie = movies[movieNumber];

		//@ <tooYoung>assert age < movie.getMinAge() assuming <junior,mv1>;
		if (age < movie.getMinAge()) {
			//System.out.println("Too young for this movie.");
			return;
		}

		int dscdPrice = calcDscdPrice(movie, age);
		//@ <pricePlausible>assert dscdPrice >= 500 assuming <dscdReg,minPr> or <dscdJun,minPr> or <dscdSen,minPr>;
		//System.out.printf("Your price: %d.%2d €\n", dscdPrice / 100, dscdPrice % 100);
	}

	private int calcDscdPrice(Movie movie, int age) {
		//@ <dscdReg>assert getDiscount(age) == 0  assuming <regular>;
		//@ <dscdJun>assert getDiscount(age) == 10 assuming <junior>;
		//@ <dscdSen>assert getDiscount(age) == 15 assuming <senior>;
		//@ <minPr>assert movie.getPrice() > 560 assuming <>;
		return movie.getPrice() - (movie.getPrice() * getDiscount(age)) / 100;
	}

	private int getDiscount(int age) {
		int discount;
		if (age < 16) {
			discount = 10;
		} else if (age >= 65) {
			discount = 15;
		} else {
			discount = 0;
		}
		return discount;
	}
}
