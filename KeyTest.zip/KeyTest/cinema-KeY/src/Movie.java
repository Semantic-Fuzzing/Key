

public final class Movie {
	public Movie(int minAge, String name, int price) {
		this.minAge = minAge;
		this.name = name;
		this.price = price;
	}
	private int minAge;
	private String name;
	private int price;
	public int getMinAge() {
		return minAge;
	}
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
}
