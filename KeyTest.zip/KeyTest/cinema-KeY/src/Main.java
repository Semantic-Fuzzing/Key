

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Movie[] movies = new Movie[] {
				new Movie(0, "Fictional", 1500),
				new Movie(16, "Indiana Jones", 1000),
				new Movie(0, "Die kleine Hexe", 570),
		};
		Cinema cin = new Cinema(movies);
		Scanner input = new Scanner(System.in);
		while (true) {
			cin.nextCustomer(input);
		}
	}
}
