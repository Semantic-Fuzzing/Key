Структура проекта:
cinema-KeY/  
├── build/  
│   ├── classes/  
│   │   ├── Cinema.class  
│   │   ├── Main.class  
│   │   └── Movie.class  
│   └── cinema.jar  
├── KeYclasspath/
│   └── java/  
│       └── util/
│            └── Scanner.java  
├── src/  
│   ├── Cinema.java  
│   ├── Main.java  
│   └── Movie.java  
├── build.xml  
├── cinema-KeY.iml  
├── cinema.iml  
└── key-2.10.0-exe.jar  

Инструкция по проверке проекта с помощью KeY:

Шаг 1: Подготовка:
1.1 - Убедитесь, что установлена Java 8+.
1.2 - Для работы с KeY требуется key-2.10.0-exe.jar (есть в проекте).

Шаг 2: Запуск KeY:
2.1 - Откройте терминал в папке cinema-KeY.
2.2 - Выполните команду: "java -jar key-2.10.0-exe.jar" (или откройте вручную key-2.10.0-exe.jar)

Шаг 3: Загрузка проекта
3.1 - В интерфейсе KeY выберите:
3.2 - File → Load...
3.3 - Укажите файл Scanner.java.
3.4 - KeY проверит корректность JML-спецификаций (если они есть) и логику программы.